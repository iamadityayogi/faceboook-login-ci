<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-12 05:06:22 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-12 05:06:22 --> Severity: Warning --> include(/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:06:22 --> Severity: Warning --> include(): Failed opening '/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/alt/php74/usr/share/pear') /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:12:39 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-12 05:12:39 --> Severity: Warning --> include(/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:12:39 --> Severity: Warning --> include(): Failed opening '/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/alt/php74/usr/share/pear') /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:13:29 --> Severity: Notice --> Undefined offset: 1 /home/q2lbj1qub9ol/public_html/facebook_login/vendor/facebook/graph-sdk/src/Facebook/Http/GraphRawResponse.php 108
ERROR - 2022-10-12 05:13:30 --> Severity: Notice --> Undefined offset: 1 /home/q2lbj1qub9ol/public_html/facebook_login/vendor/facebook/graph-sdk/src/Facebook/Http/GraphRawResponse.php 108
ERROR - 2022-10-12 05:14:31 --> Severity: Notice --> Undefined offset: 1 /home/q2lbj1qub9ol/public_html/facebook_login/vendor/facebook/graph-sdk/src/Facebook/Http/GraphRawResponse.php 108
ERROR - 2022-10-12 05:14:31 --> [FACEBOOK PHP SDK] code: 100 | message: This authorization code has been used.
ERROR - 2022-10-12 05:15:01 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-12 05:15:01 --> Severity: Warning --> include(/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:15:01 --> Severity: Warning --> include(): Failed opening '/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/alt/php74/usr/share/pear') /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:15:05 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-12 05:15:05 --> Severity: Warning --> include(/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:15:05 --> Severity: Warning --> include(): Failed opening '/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/alt/php74/usr/share/pear') /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:17:21 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-12 05:17:21 --> Severity: Warning --> include(/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:17:21 --> Severity: Warning --> include(): Failed opening '/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/alt/php74/usr/share/pear') /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:17:28 --> Severity: Notice --> Undefined offset: 1 /home/q2lbj1qub9ol/public_html/facebook_login/vendor/facebook/graph-sdk/src/Facebook/Http/GraphRawResponse.php 108
ERROR - 2022-10-12 05:17:29 --> Severity: Notice --> Undefined offset: 1 /home/q2lbj1qub9ol/public_html/facebook_login/vendor/facebook/graph-sdk/src/Facebook/Http/GraphRawResponse.php 108
ERROR - 2022-10-12 05:17:30 --> Severity: Notice --> Undefined offset: 1 /home/q2lbj1qub9ol/public_html/facebook_login/vendor/facebook/graph-sdk/src/Facebook/Http/GraphRawResponse.php 108
ERROR - 2022-10-12 05:17:33 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-12 05:17:33 --> Severity: Warning --> include(/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:17:33 --> Severity: Warning --> include(): Failed opening '/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/alt/php74/usr/share/pear') /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:18:02 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-12 05:18:02 --> Severity: Warning --> include(/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-12 05:18:02 --> Severity: Warning --> include(): Failed opening '/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/alt/php74/usr/share/pear') /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182

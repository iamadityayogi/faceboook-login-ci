<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-13 12:38:24 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-13 12:38:24 --> Severity: Warning --> include(/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-13 12:38:24 --> Severity: Warning --> include(): Failed opening '/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/alt/php74/usr/share/pear') /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-13 12:54:58 --> Severity: Notice --> Undefined offset: 1 /home/q2lbj1qub9ol/public_html/facebook_login/vendor/facebook/graph-sdk/src/Facebook/Http/GraphRawResponse.php 108
ERROR - 2022-10-13 12:54:58 --> Severity: Notice --> Undefined offset: 1 /home/q2lbj1qub9ol/public_html/facebook_login/vendor/facebook/graph-sdk/src/Facebook/Http/GraphRawResponse.php 108
ERROR - 2022-10-13 12:55:02 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-13 12:55:02 --> Severity: Warning --> include(/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-13 12:55:02 --> Severity: Warning --> include(): Failed opening '/home/q2lbj1qub9ol/public_html/facebook_login/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/alt/php74/usr/share/pear') /home/q2lbj1qub9ol/public_html/facebook_login/system/core/Exceptions.php 182
ERROR - 2022-10-13 12:55:04 --> Severity: Notice --> Undefined offset: 1 /home/q2lbj1qub9ol/public_html/facebook_login/vendor/facebook/graph-sdk/src/Facebook/Http/GraphRawResponse.php 108
ERROR - 2022-10-13 12:55:04 --> Severity: Notice --> Undefined offset: 1 /home/q2lbj1qub9ol/public_html/facebook_login/vendor/facebook/graph-sdk/src/Facebook/Http/GraphRawResponse.php 108
